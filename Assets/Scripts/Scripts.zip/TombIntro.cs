using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// TombIntro — Plays the opening cinematic when the scene starts.
///
/// SEQUENCE:
///   1. ChickController is locked — player can't move yet.
///   2. Short dramatic pause.
///   3. Rock begins to roll to the side (translate + rotate).
///   4. Debris/dust particles fire as the rock moves.
///   5. Rock settles. Opening particles play.
///   6. Intro text fades in with a sound.
///   7. Text holds, then fades out.
///   8. ChickController unlocked — player is free.
///
/// SETUP:
///   - Attach this script to an empty "Intro" GameObject in the scene.
///   - The Rock should be a child of its own pivot so rotation feels natural.
///     e.g.   RockPivot (move/rotate this)
///                └── RockMesh
///   - Place particle systems at the rock seam and cave opening.
///
/// UI HIERARCHY (same Canvas as DeathScreen is fine, different sort order):
///   IntroCanvas  (Canvas, Screen Space Overlay, starts ENABLED)
///     └── IntroPanel  (CanvasGroup, alpha 0)
///           └── IntroText  (TMP_Text)
/// </summary>
public class TombIntro : MonoBehaviour
{
    // ─────────────────────────────────────────────────────────────
    //  Inspector
    // ─────────────────────────────────────────────────────────────

    [Header("── References ─────────────────────")]
    [Tooltip("The ChickController — locked during the cinematic")]
    public ChickController chick;
    [Tooltip("The rock's pivot Transform that will be moved and rotated")]
    public Transform rockPivot;

    [Header("── Rock Motion ─────────────────────")]
    [Tooltip("How far the rock slides in its local space (from X=0 to X=7)")]
    public Vector3 rollTranslation  = new Vector3(7f, 0f, 0f);
    [Tooltip("How many degrees the rock rotates as it rolls (around local Z — negative = rolls right)")]
    public float   rollAngle        = -180f;
    [Tooltip("Total duration of the roll animation")]
    public float   rollDuration     = 2.2f;
    [Tooltip("Shape of the roll — slow start, fast middle, slight ease at end")]
    public AnimationCurve rollCurve = new AnimationCurve(
        new Keyframe(0.00f, 0f, 0f,  0f),
        new Keyframe(0.35f, 0.08f),
        new Keyframe(0.75f, 0.82f),
        new Keyframe(1.00f, 1f, 1.5f, 0f)
    );

    [Header("── Particles ───────────────────────")]
    [Tooltip("Debris/dust that fires as the rock first moves (at the rock seam)")]
    public ParticleSystem rockSeamDust;
    [Tooltip("How far into the roll to start the seam particles (0-1)")]
    [Range(0f, 1f)]
    public float  seamParticleStartT = 0.05f;
    [Tooltip("Dust/light rays that play at the cave opening once the rock is clear")]
    public ParticleSystem openingDust;
    [Tooltip("Small debris/pebbles that fall from the opening")]
    public ParticleSystem openingDebris;

    [Header("── Audio ───────────────────────────")]
    public AudioSource audioSource;
    [Tooltip("Played when the rock starts to move — deep grinding rumble")]
    public AudioClip   rockRumbleSFX;
    [Tooltip("Played when the rock settles into its final position")]
    public AudioClip   rockThudSFX;
    [Tooltip("Played as the intro text appears")]
    public AudioClip   revelationSFX;

    [Header("── Timing ──────────────────────────")]
    [Tooltip("Pause before anything moves — builds suspense")]
    public float prePause           = 1.0f;
    [Tooltip("Delay after rock settles before text appears")]
    public float postRockPause      = 0.6f;

    [Header("── Intro Text ──────────────────────")]
    public CanvasGroup introPanel;      // the panel CanvasGroup
    public TMP_Text    introText;       // the TMP text child
    [TextArea]
    public string      introMessage    = "He is risen.";
    public float       textFadeIn      = 0.8f;
    [Tooltip("How long the text stays fully visible")]
    public float       textHold        = 2.5f;
    public float       textFadeOut     = 0.8f;

    // ─────────────────────────────────────────────────────────────

    Vector3    _rockStartPos;
    Quaternion _rockStartRot;

    void Start()
    {
        if (rockPivot)
        {
            _rockStartPos = rockPivot.localPosition;
            _rockStartRot = rockPivot.localRotation;
        }

        // Make sure intro panel starts invisible
        if (introPanel) introPanel.alpha = 0f;
        if (introText)  introText.text   = introMessage;

        // Particles off until we want them
        StopParticles(rockSeamDust);
        StopParticles(openingDust);
        StopParticles(openingDebris);

        StartCoroutine(IntroSequence());
    }

    // ─────────────────────────────────────────────────────────────
    //  Main sequence
    // ─────────────────────────────────────────────────────────────

    IEnumerator IntroSequence()
    {
        // ── 1. Suspenseful pause ─────────────────────────────────
        yield return new WaitForSeconds(prePause);

        // ── 2. Rock rumble starts ────────────────────────────────
        PlaySound(rockRumbleSFX);

        // ── 3. Roll the rock ─────────────────────────────────────
        yield return RollRock();

        // ── 4. Thud + opening particles ─────────────────────────
        PlaySound(rockThudSFX);
        StartParticles(openingDust);
        StartParticles(openingDebris);

        // ── 5. Intro text ────────────────────────────────────────
        PlaySound(revelationSFX);
        yield return Fade(introPanel, 0f, 1f, textFadeIn);
        yield return new WaitForSeconds(textHold);
        yield return Fade(introPanel, 1f, 0f, textFadeOut);

        // ── 6. Done ──────────────────────────────────────────────
        // Player was free the whole time — nothing to unlock.
    }

    // ─────────────────────────────────────────────────────────────
    //  Rock roll coroutine
    // ─────────────────────────────────────────────────────────────

    IEnumerator RollRock()
    {
        if (!rockPivot) yield break;

        // Work in local space
        Vector3    endLocalPos = _rockStartPos + rollTranslation;
        Quaternion endLocalRot = _rockStartRot * Quaternion.Euler(0f, 0f, rollAngle);

        bool seamStarted = false;
        float elapsed    = 0f;

        while (elapsed < rollDuration)
        {
            elapsed    += Time.deltaTime;
            float t     = Mathf.Clamp01(elapsed / rollDuration);
            float tCurve = rollCurve.Evaluate(t);

            rockPivot.localPosition = Vector3.Lerp(_rockStartPos, endLocalPos, tCurve);
            rockPivot.localRotation = Quaternion.Slerp(_rockStartRot, endLocalRot, tCurve);

            // Fire seam dust once we reach the start threshold
            if (!seamStarted && t >= seamParticleStartT)
            {
                seamStarted = true;
                StartParticles(rockSeamDust);
            }

            yield return null;
        }

        // Snap to final position cleanly
        rockPivot.localPosition = endLocalPos;
        rockPivot.localRotation = endLocalRot;

        // Stop seam dust — opening is clean now
        StopParticles(rockSeamDust);
    }

    // ─────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────

    IEnumerator Fade(CanvasGroup cg, float from, float to, float duration)
    {
        if (cg == null) yield break;
        float elapsed = 0f;
        cg.alpha = from;
        while (elapsed < duration)
        {
            elapsed  += Time.deltaTime;
            cg.alpha  = Mathf.Lerp(from, to, elapsed / duration);
            yield return null;
        }
        cg.alpha = to;
    }

    void PlaySound(AudioClip clip)
    {
        if (audioSource != null && clip != null)
            audioSource.PlayOneShot(clip);
    }

    void StartParticles(ParticleSystem ps)
    {
        if (ps != null) ps.Play();
    }

    void StopParticles(ParticleSystem ps)
    {
        if (ps != null) ps.Stop();
    }
}