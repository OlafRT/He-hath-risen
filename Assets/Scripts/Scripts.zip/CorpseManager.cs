using System;
using System.Collections.Generic;
using UnityEngine;

// ─────────────────────────────────────────────────────────────────────────────
//  Data — one saved corpse
// ─────────────────────────────────────────────────────────────────────────────

[Serializable]
public class CorpseData
{
    // World-space root transform (used as fallback for spikes without an ID)
    public SerializedVector3    position;
    public SerializedQuaternion rotation;

    // Scale-FREE spike-local transform.
    // Stored as: posOffset = Inverse(spikeRot) * (worldPos - spikePos)
    //            rotOffset = Inverse(spikeRot) * worldRot
    // Reconstructed as: worldPos = spikePos + spikeRot * posOffset
    //                   worldRot = spikeRot * rotOffset
    // Scale is never involved, so no squishing on non-uniform spikes.
    public string               spikeId;
    public SerializedVector3    localPosition;   // scale-free local offset
    public SerializedQuaternion localRotation;   // rotation offset from spike

    // Limb local rotations (snapshotted at moment of death)
    public SerializedQuaternion bodyRot;
    public SerializedVector3    bodyScale;
    public SerializedQuaternion rightLegRot;
    public SerializedQuaternion leftLegRot;
    public SerializedQuaternion rightWingRot;
    public SerializedQuaternion leftWingRot;
    public SerializedQuaternion headRot;
}

[Serializable] public struct SerializedVector3
{
    public float x, y, z;
    public SerializedVector3(Vector3 v) { x = v.x; y = v.y; z = v.z; }
    public Vector3 ToVector3() => new Vector3(x, y, z);
}

[Serializable] public struct SerializedQuaternion
{
    public float x, y, z, w;
    public SerializedQuaternion(Quaternion q) { x = q.x; y = q.y; z = q.z; w = q.w; }
    public Quaternion ToQuaternion() => new Quaternion(x, y, z, w);
}

[Serializable]
class CorpseDataList { public List<CorpseData> corpses = new List<CorpseData>(); }

// ─────────────────────────────────────────────────────────────────────────────
//  CorpseManager
// ─────────────────────────────────────────────────────────────────────────────

/// <summary>
/// CorpseManager — Persists chick corpses across runs via PlayerPrefs.
///
/// SETUP:
///   - Attach to an empty GameObject in the scene (call it "CorpseManager").
///   - Assign the Corpse Prefab — a duplicate of the chick's visual hierarchy
///     (Body + all limb pivots + meshes) with ALL scripts and colliders removed.
///   - The prefab must have this child structure (matching ChickController):
///       [Root]
///         └── Body
///               ├── RightLeg
///               ├── LeftLeg
///               ├── RightWing
///               ├── LeftWing
///               └── Head
///   - Set Max Corpses to control how many are saved (oldest are discarded).
///   - For corpses to ride moving spikes across reloads, add a SpikeIdentifier
///     component to each spike root and generate a unique ID for it.
///
/// SCALE NOTE:
///   Corpses are NEVER childed to their spike. Instead, a CorpseFollower component
///   is added to each spike-tracked corpse. It follows the spike's position and
///   rotation every LateUpdate using only rotation math — scale is never inherited,
///   so corpses on scaled spikes always look correct.
/// </summary>
public class CorpseManager : MonoBehaviour
{
    public static CorpseManager Instance { get; private set; }

    [Header("── Setup ───────────────────────────")]
    [Tooltip("A prefab of the chick's visual hierarchy only — no scripts, no colliders")]
    public GameObject corpsePrefab;
    [Tooltip("Maximum number of corpses kept across all runs")]
    public int maxCorpses = 20;

    const string PREFS_KEY = "ChickCorpses";

    // ─────────────────────────────────────────────────────────────

    void Awake()
    {
        if (Instance != null && Instance != this) { Destroy(gameObject); return; }
        Instance = this;
    }

    void Start()
    {
        SpawnSavedCorpses();
    }

    // ─────────────────────────────────────────────────────────────
    //  Public API
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// Saves a new corpse and immediately spawns it in the scene.
    /// spikeTransform — the spike root this corpse is impaled on.
    /// If it has a SpikeIdentifier, the corpse will be re-attached after reloads.
    /// </summary>
    public void RegisterCorpse(CorpseData data, Transform spikeTransform = null)
    {
        if (spikeTransform != null)
        {
            SpikeIdentifier identifier = spikeTransform.GetComponent<SpikeIdentifier>();
            if (identifier != null)
            {
                data.spikeId = identifier.Id;

                // Store offset in SCALE-FREE spike-local space.
                // Only spike rotation is used — no InverseTransformPoint, which would
                // bake in the spike's lossy scale and cause position drift on scaled spikes.
                Vector3    worldPos = data.position.ToVector3();
                Quaternion worldRot = data.rotation.ToQuaternion();

                data.localPosition = new SerializedVector3(
                    Quaternion.Inverse(spikeTransform.rotation) * (worldPos - spikeTransform.position));
                data.localRotation = new SerializedQuaternion(
                    Quaternion.Inverse(spikeTransform.rotation) * worldRot);
            }
        }

        CorpseDataList list = LoadList();
        list.corpses.Add(data);

        while (list.corpses.Count > maxCorpses)
            list.corpses.RemoveAt(0);

        SaveList(list);
        SpawnCorpse(data, spikeTransform);
    }

    // ─────────────────────────────────────────────────────────────
    //  Spawn
    // ─────────────────────────────────────────────────────────────

    void SpawnSavedCorpses()
    {
        CorpseDataList list = LoadList();
        foreach (CorpseData d in list.corpses)
            SpawnCorpse(d);
    }

    void SpawnCorpse(CorpseData d, Transform spikeTransform = null)
    {
        if (corpsePrefab == null) return;

        Vector3    worldPos;
        Quaternion worldRot;
        Transform  followerSpike = null;   // the spike to hand to CorpseFollower, if any

        if (spikeTransform != null)
        {
            // ── Fresh death this session ─────────────────────────────────
            // World position is exactly where SpikeKill placed the victim.
            worldPos     = d.position.ToVector3();
            worldRot     = d.rotation.ToQuaternion();
            followerSpike = spikeTransform;
        }
        else if (!string.IsNullOrEmpty(d.spikeId)
                 && SpikeIdentifier.TryGet(d.spikeId, out Transform spike))
        {
            // ── Reload: spike found by stable ID ─────────────────────────
            // Reconstruct world position from the SCALE-FREE local offset.
            // spikePos + spikeRot * localPosOffset  (no scale anywhere)
            worldPos     = spike.position + spike.rotation * d.localPosition.ToVector3();
            worldRot     = spike.rotation * d.localRotation.ToQuaternion();
            followerSpike = spike;
        }
        else
        {
            // ── Fallback: static spike or no SpikeIdentifier ─────────────
            worldPos = d.position.ToVector3();
            worldRot = d.rotation.ToQuaternion();
        }

        GameObject go = Instantiate(corpsePrefab, worldPos, worldRot);

        // Attach CorpseFollower instead of SetParent.
        // The corpse is NEVER a child in the hierarchy — it just tracks the spike's
        // position + rotation each LateUpdate, with zero scale inheritance.
        if (followerSpike != null)
            go.AddComponent<CorpseFollower>().Init(followerSpike, worldPos, worldRot);

        ApplyLimbRotations(go, d);
    }

    // ─────────────────────────────────────────────────────────────
    //  Limb pose
    // ─────────────────────────────────────────────────────────────

    void ApplyLimbRotations(GameObject root, CorpseData d)
    {
        Transform body = root.transform.Find("Body");
        if (body == null) return;

        body.localRotation = d.bodyRot.ToQuaternion();
        body.localScale    = d.bodyScale.ToVector3();

        SetLocalRot(body, "RightLeg",  d.rightLegRot);
        SetLocalRot(body, "LeftLeg",   d.leftLegRot);
        SetLocalRot(body, "RightWing", d.rightWingRot);
        SetLocalRot(body, "LeftWing",  d.leftWingRot);
        SetLocalRot(body, "Head",      d.headRot);
    }

    void SetLocalRot(Transform parent, string childName, SerializedQuaternion rot)
    {
        Transform t = parent.Find(childName);
        if (t != null) t.localRotation = rot.ToQuaternion();
    }

    // ─────────────────────────────────────────────────────────────
    //  Persistence
    // ─────────────────────────────────────────────────────────────

    CorpseDataList LoadList()
    {
        if (!PlayerPrefs.HasKey(PREFS_KEY))
            return new CorpseDataList();
        try
        {
            return JsonUtility.FromJson<CorpseDataList>(PlayerPrefs.GetString(PREFS_KEY))
                   ?? new CorpseDataList();
        }
        catch { return new CorpseDataList(); }
    }

    void SaveList(CorpseDataList list)
    {
        PlayerPrefs.SetString(PREFS_KEY, JsonUtility.ToJson(list));
        PlayerPrefs.Save();
    }

    public void ClearAllCorpses()
    {
        PlayerPrefs.DeleteKey(PREFS_KEY);
        PlayerPrefs.Save();
    }
}
