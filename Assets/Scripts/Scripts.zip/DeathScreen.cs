using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

/// <summary>
/// DeathScreen — Attach to the DeathScreen GameObject.
///
/// EXPECTED HIERARCHY:
///   UI  (Canvas)
///     └── DeathScreen  ← this script here
///           ├── TextBackGround  (Image + CanvasGroup)  ← textPanel
///           │     └── Text (TMP)                       ← deathLabel
///           └── BlackOverlay  (Image, full screen + CanvasGroup) ← blackOverlay
///
/// Both CanvasGroups should start at alpha 0 in the Inspector.
/// The UI Canvas should start DISABLED — Show() enables it.
/// </summary>
public class DeathScreen : MonoBehaviour
{
    [Header("── References ─────────────────────")]
    public CanvasGroup textPanel;       // TextBackGround's CanvasGroup
    public TMP_Text    deathLabel;      // Text (TMP) child of TextBackGround
    public CanvasGroup blackOverlay;    // Full-screen black CanvasGroup

    [Header("── Audio ───────────────────────────")]
    public AudioSource audioSource;
    public AudioClip   deathSFX;

    [Header("── Text ────────────────────────────")]
    public string deathText = "You Died";

    [Header("── Timing ──────────────────────────")]
    [Tooltip("How long the text panel takes to fade in")]
    public float panelFadeDuration  = 0.6f;
    [Tooltip("How long to sit on the text before fading to black")]
    public float holdDuration       = 1.8f;
    [Tooltip("How long the black fade takes")]
    public float blackFadeDuration  = 0.7f;
    [Tooltip("Brief pause on black before reloading (feels more deliberate)")]
    public float holdBlackDuration  = 0.3f;

    // ─────────────────────────────────────────────────────────────

    void Awake()
    {
        if (textPanel)    textPanel.alpha    = 0f;
        if (blackOverlay) blackOverlay.alpha = 0f;

        gameObject.SetActive(false);
    }

    public void Show()
    {
        gameObject.SetActive(true);
        if (deathLabel) deathLabel.text = deathText;
        if (audioSource != null && deathSFX != null)
            audioSource.PlayOneShot(deathSFX);
        StartCoroutine(DeathSequence());
        if (GameStats.Instance != null) GameStats.Instance.AddDeath();
    }

    IEnumerator DeathSequence()
    {
        // ── 1. Fade in text panel ────────────────────────────────
        yield return Fade(textPanel, 0f, 1f, panelFadeDuration);

        // ── 2. Hold so the player can read it ───────────────────
        yield return new WaitForSeconds(holdDuration);

        // ── 3. Fade in black overlay ─────────────────────────────
        yield return Fade(blackOverlay, 0f, 1f, blackFadeDuration);

        // ── 4. Brief pause on black ──────────────────────────────
        yield return new WaitForSeconds(holdBlackDuration);

        // ── 5. Restart ───────────────────────────────────────────
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

    IEnumerator Fade(CanvasGroup cg, float from, float to, float duration)
    {
        if (cg == null) yield break;

        float elapsed = 0f;
        cg.alpha = from;

        while (elapsed < duration)
        {
            elapsed  += Time.deltaTime;
            cg.alpha  = Mathf.Lerp(from, to, elapsed / duration);
            yield return null;
        }

        cg.alpha = to;
    }
}