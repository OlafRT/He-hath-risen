using System.Collections;
using UnityEngine;

/// <summary>
/// ChickusMaximus — Relentless gladiator chick predator.
/// He cannot be killed. He only wants one thing.
///
/// SETUP:
///   - Same hierarchy as the player chick:
///       [Root]  ← this script + CharacterController
///         └── Body
///               ├── RightLeg
///               ├── LeftLeg
///               ├── RightWing   ← spike is a child of this
///               ├── LeftWing
///               └── Head
///   - Scale the root up slightly (e.g. 1.3x) for big boy energy.
///   - Tag your ChickController player GameObject as "Player".
///   - Add a CharacterController to the root and tune it to match the mesh.
///
/// AGGRESSION:
///   The longer he chases you, the faster and more dangerous he becomes.
///   Attacks unlock progressively — combos and feints first, then the charge.
///   If he keeps missing, he forces a charge to close the gap.
/// </summary>
[RequireComponent(typeof(CharacterController))]
public class ChickusMaximus : MonoBehaviour
{
    // ─────────────────────────────────────────────────────────────
    //  Inspector
    // ─────────────────────────────────────────────────────────────

    [Header("── Transforms ──────────────────────")]
    public Transform body;
    public Transform rightLeg;
    public Transform leftLeg;
    public Transform rightWing;
    public Transform leftWing;
    public Transform head;
    [Tooltip("Empty at the point where Chickus grips the spike (near the base)")]
    public Transform spikeHandle;
    [Tooltip("The spike tip — already exists on your spike setup")]
    public Transform spikeTip;

    [Header("── Movement ───────────────────────")]
    public float moveSpeed     = 3.8f;
    public float rotationSpeed = 8f;
    public float gravity       = -20f;

    [Header("── Detection ──────────────────────")]
    [Tooltip("Radius in which Chickus first notices the player")]
    public float detectionRadius = 9f;
    [Tooltip("He won't stop until the player is THIS far away. Keep high for relentlessness.")]
    public float loseRadius = 30f;

    [Header("── Aggression ──────────────────────")]
    [Tooltip("Seconds of chasing before reaching maximum aggression")]
    public float aggressionRampTime = 25f;
    [Tooltip("Speed multiplier at maximum aggression")]
    public float maxSpeedMult = 1.65f;
    [Tooltip("Attack cooldown multiplier at max aggression (lower = more frequent attacks)")]
    public float minCooldownMult = 0.45f;
    [Tooltip("Aggression level (0-1) at which combos and feints unlock")]
    public float comboUnlockThreshold = 0.3f;
    [Tooltip("Aggression level at which the charge attack unlocks")]
    public float chargeUnlockThreshold = 0.65f;

    [Header("── Attack ─────────────────────────")]
    [Tooltip("Distance at which he begins an attack")]
    public float attackRange    = 2.2f;
    [Tooltip("Base seconds between attacks (scaled down by aggression)")]
    public float attackCooldown = 1.4f;
    [Tooltip("How far forward he lunges — grows slightly with aggression")]
    public float lungeDistance  = 1.1f;
    [Tooltip("Duration of the lunge movement")]
    public float lungeDuration  = 0.18f;
    [Tooltip("After this many missed attacks in a row, forces a charge")]
    public int   missesBeforeCharge = 3;

    [Header("── Circle / Strafe ─────────────────")]
    [Tooltip("He'll orbit you for this long before committing to an attack")]
    public float circleTimeMin = 0.6f;
    public float circleTimeMax = 1.8f;
    public float circleRadius  = 2.6f;
    public float circleSpeed   = 2.4f;

    [Header("── Charge Attack ────────────────────")]
    [Tooltip("How long he rears back before the charge — the player's window to read and dodge")]
    public float chargeWindupTime = 0.60f;
    [Tooltip("Sprint speed during the charge")]
    public float chargeSpeed      = 9.5f;
    [Tooltip("How long the charge lasts")]
    public float chargeDuration   = 0.50f;
    [Tooltip("Hit detection radius during the charge (larger — it's a body slam)")]
    public float chargeHitRadius  = 0.80f;

    [Header("── Feint ───────────────────────────")]
    [Tooltip("How long he holds the wind-up to bait your dodge, then strikes from a new angle")]
    public float feintHesitateTime = 0.38f;

    [Header("── Leg Animation ──────────────────")]
    public float legSwingAngle = 32f;
    public float legSwingSpeed = 8f;

    [Header("── Body Animation ─────────────────")]
    public float bodyBobHeight = 0.06f;
    public float bodyBobSpeed  = 8f;
    public float bodyRunLean   = 10f;

    [Header("── Head Animation ─────────────────")]
    public float headNodAngle = 10f;
    public float headIdleLook = 12f;

    [Header("── Wing / Spike Pose ──────────────")]
    [Tooltip("Resting 'carrying the spike' local rotation of the left wing")]
    public Vector3 spikeCarryRotation  = new Vector3(0f,   0f, -70f);
    [Tooltip("Wind-up local rotation — spike pulls back before the stab")]
    public Vector3 spikeWindupRotation = new Vector3(0f, -40f, -50f);
    [Tooltip("Idle right wing drift amount")]
    public float   rightWingIdleDrift  = 4f;

    [Header("── Jumping ─────────────────────────")]
    [Tooltip("Upward velocity applied when jumping to follow the player")]
    public float jumpForce          = 10f;
    [Tooltip("How many units above Chickus the player must be before he jumps to follow")]
    public float jumpHeightThreshold = 1.4f;
    [Tooltip("Minimum seconds between jumps — prevents frantic bunny-hopping")]
    public float jumpCooldown        = 1.6f;
    [Tooltip("Horizontal distance within which a mid-air jump attack can trigger")]
    public float jumpAttackRange     = 3.5f;

    [Header("── Audio ───────────────────────────")]
    public AudioSource audioSource;
    [Tooltip("Spike pulling back — plays at start of every wind-up")]
    public AudioClip stabWindupSFX;
    [Tooltip("Thrust sound — plays at the moment of every lunge")]
    public AudioClip stabLungeSFX;
    [Tooltip("Grunt/roar during charge wind-up")]
    public AudioClip chargeRoarSFX;
    [Tooltip("Heavy jump grunt when he leaps")]
    public AudioClip jumpSFX;
    [Tooltip("Thud when he lands")]
    public AudioClip landSFX;
    [Tooltip("Periodic footstep cluck while chasing")]
    public AudioClip footstepSFX;
    [Tooltip("Seconds between footstep sounds")]
    public float footstepInterval = 0.38f;

    // ─────────────────────────────────────────────────────────────
    //  State machine
    // ─────────────────────────────────────────────────────────────

    enum State      { Idle, Chase, Circle, Attack }
    enum AttackType { SingleStab, StabCombo, Feint, Charge, JumpAttack }

    State _state = State.Idle;

    // ─────────────────────────────────────────────────────────────
    //  Private
    // ─────────────────────────────────────────────────────────────

    CharacterController _cc;
    Transform           _player;

    float _verticalVelocity;
    float _legTimer;
    float _bodyBobTimer;
    float _attackCooldownTimer;
    float _idleLookTimer;
    float _chaseTimer;          // accumulates while chasing — drives aggression
    float _circleTimer;
    float _circleDir = 1f;
    int   _consecutiveMisses;
    bool  _isAttacking;
    bool  _isGrounded;
    bool  _wasGrounded;

    float _jumpCooldownTimer;
    float _footstepTimer;

    // Shared lunge state — set by DoLunge(), read by callers after yield
    Vector3 _lungeOrigin;

    // Cached rest transforms
    Vector3    _bodyRestPos;
    Vector3    _bodyRestScale;
    Quaternion _rightLegRest, _leftLegRest;
    Quaternion _rightWingRest, _leftWingRest;
    Quaternion _headRest;
    Quaternion _spikeCarryRot;
    Quaternion _spikeWindupRot;

    // ─────────────────────────────────────────────────────────────
    //  Derived — everything scales with aggression
    // ─────────────────────────────────────────────────────────────

    /// 0 = just started chasing, 1 = maximum fury
    float Aggression      => Mathf.Clamp01(_chaseTimer / aggressionRampTime);
    float SpeedMult       => Mathf.Lerp(1f, maxSpeedMult,    Aggression);
    float CooldownMult    => Mathf.Lerp(1f, minCooldownMult, Aggression);
    float CurrentSpeed    => moveSpeed     * SpeedMult;
    float CurrentCooldown => attackCooldown * CooldownMult;
    /// Lunge distance grows slightly as he gets angrier
    float CurrentLunge    => lungeDistance  * Mathf.Lerp(1f, 1.35f, Aggression);
    /// Wind-up shortens at high aggression — harder to read at full rage
    float CurrentWindup   => Mathf.Lerp(0.22f, 0.13f, Aggression);

    // ─────────────────────────────────────────────────────────────

    void Start()
    {
        _cc = GetComponent<CharacterController>();

        GameObject playerGO = GameObject.FindGameObjectWithTag("Player");
        if (playerGO != null)
            _player = playerGO.transform;

        if (body)      { _bodyRestPos = body.localPosition; _bodyRestScale = body.localScale; }
        if (rightLeg)  _rightLegRest  = rightLeg.localRotation;
        if (leftLeg)   _leftLegRest   = leftLeg.localRotation;
        if (rightWing) _rightWingRest = rightWing.localRotation;
        if (leftWing)  _leftWingRest  = leftWing.localRotation;
        if (head)      _headRest      = head.localRotation;

        _spikeCarryRot  = _leftWingRest * Quaternion.Euler(spikeCarryRotation);
        _spikeWindupRot = _leftWingRest * Quaternion.Euler(spikeWindupRotation);
    }

    void Update()
    {
        if (_isAttacking) return;

        UpdateState();
        HandleMovement();
        HandleAnimation();

        if (_attackCooldownTimer > 0f)
            _attackCooldownTimer -= Time.deltaTime;

        if (_jumpCooldownTimer > 0f)
            _jumpCooldownTimer -= Time.deltaTime;
    }

    // ─────────────────────────────────────────────────────────────
    //  State
    // ─────────────────────────────────────────────────────────────

    void UpdateState()
    {
        if (_player == null) return;

        float dist = Vector3.Distance(transform.position, _player.position);

        switch (_state)
        {
            case State.Idle:
                if (dist <= detectionRadius)
                {
                    _state      = State.Chase;
                    _chaseTimer = 0f;
                }
                break;

            case State.Chase:
                _chaseTimer += Time.deltaTime;

                if (dist > loseRadius)
                {
                    // Player escaped — he gives up. For now.
                    _state      = State.Idle;
                    _chaseTimer = 0f;
                    break;
                }

                if (_attackCooldownTimer <= 0f && dist <= attackRange)
                {
                    AttackType attack = PickAttack(dist);

                    // At low aggression: circle first — he's sizing you up
                    // At high aggression: goes straight for the throat
                    float circleChance = Mathf.Lerp(0.55f, 0.1f, Aggression);
                    if (attack != AttackType.Charge && Random.value < circleChance)
                        StartCoroutine(CircleThenAttack(attack));
                    else
                        LaunchAttack(attack);
                }
                else if (_attackCooldownTimer <= 0f && dist <= attackRange * 2f
                         && Aggression >= 0.2f && Random.value < 0.008f)
                {
                    // Occasional creepy orbit when nearby — unsettling predator behaviour
                    EnterCircle();
                }
                break;

            case State.Circle:
                _chaseTimer  += Time.deltaTime;
                _circleTimer -= Time.deltaTime;

                if (dist > loseRadius)
                {
                    _state = State.Chase;
                    break;
                }

                // Randomly flip orbit direction — unpredictable
                if (Random.value < 0.004f) _circleDir *= -1f;

                if (_circleTimer <= 0f || (_attackCooldownTimer <= 0f && dist <= attackRange))
                    LaunchAttack(PickAttack(dist));
                break;

            case State.Attack:
                // Owned by attack coroutines
                break;
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Attack selection
    // ─────────────────────────────────────────────────────────────

    AttackType PickAttack(float dist)
    {
        // Too many misses in a row — force a charge to close the gap
        if (_consecutiveMisses >= missesBeforeCharge && Aggression >= chargeUnlockThreshold)
            return AttackType.Charge;

        // If the player is airborne and within jump-attack range, leap after them
        bool playerIsAirborne = _player != null &&
                                (_player.position.y - transform.position.y) > jumpHeightThreshold * 0.5f;
        float hDist = _player != null
            ? Vector2.Distance(new Vector2(transform.position.x, transform.position.z),
                               new Vector2(_player.position.x,   _player.position.z))
            : 999f;

        if (playerIsAirborne && hDist <= jumpAttackRange && _jumpCooldownTimer <= 0f)
            return AttackType.JumpAttack;

        float r = Random.value;

        // Charge: available at high aggression when player is a bit further away
        if (Aggression >= chargeUnlockThreshold && dist > attackRange * 1.1f && r < 0.28f)
            return AttackType.Charge;

        // Combos and feints unlock at mid aggression
        if (Aggression >= comboUnlockThreshold)
        {
            if (r < 0.35f) return AttackType.StabCombo;
            if (r < 0.56f) return AttackType.Feint;
        }

        return AttackType.SingleStab;
    }

    void LaunchAttack(AttackType type)
    {
        _state = State.Attack;
        switch (type)
        {
            case AttackType.SingleStab: StartCoroutine(SingleStabRoutine()); break;
            case AttackType.StabCombo:  StartCoroutine(StabComboRoutine());  break;
            case AttackType.Feint:      StartCoroutine(FeintRoutine());       break;
            case AttackType.Charge:     StartCoroutine(ChargeRoutine());      break;
            case AttackType.JumpAttack: StartCoroutine(JumpAttackRoutine());  break;
        }
    }

    void EnterCircle()
    {
        _state       = State.Circle;
        _circleTimer = Random.Range(circleTimeMin, circleTimeMax);
        _circleDir   = Random.value < 0.5f ? 1f : -1f;
    }

    // ─────────────────────────────────────────────────────────────
    //  Movement
    // ─────────────────────────────────────────────────────────────

    void HandleMovement()
    {
        // ── Ground tracking ───────────────────────────────────────
        _wasGrounded = _isGrounded;
        _isGrounded  = _cc.isGrounded;

        if (_isGrounded && !_wasGrounded)
            PlaySound(landSFX);   // thud on landing

        if (_player != null)
        {
            float   dist     = Vector3.Distance(transform.position, _player.position);
            Vector3 toPlayer = _player.position - transform.position;
            toPlayer.y = 0f;

            if (_state == State.Chase && toPlayer.magnitude > 0.1f)
            {
                Quaternion targetRot = Quaternion.LookRotation(toPlayer.normalized);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRot,
                    Time.deltaTime * rotationSpeed);

                if (dist > attackRange * 0.8f)
                    _cc.Move(toPlayer.normalized * CurrentSpeed * Time.deltaTime);

                // ── Jump to follow player onto platforms ──────────
                float heightDiff = _player.position.y - transform.position.y;
                if (_isGrounded && heightDiff > jumpHeightThreshold && _jumpCooldownTimer <= 0f)
                {
                    _verticalVelocity  = jumpForce;
                    _jumpCooldownTimer = jumpCooldown;
                    PlaySound(jumpSFX);
                }
            }
            else if (_state == State.Circle && toPlayer.magnitude > 0.1f)
            {
                // Always face the player while orbiting
                transform.rotation = Quaternion.Slerp(transform.rotation,
                    Quaternion.LookRotation(toPlayer.normalized),
                    Time.deltaTime * rotationSpeed * 1.5f);

                // Strafe perpendicular, nudge in/out to hold orbit radius
                Vector3 right      = Vector3.Cross(Vector3.up, toPlayer.normalized);
                Vector3 strafe     = right * _circleDir;
                float   distDelta  = dist - circleRadius;
                Vector3 correction = toPlayer.normalized * Mathf.Clamp(distDelta, -1f, 1f) * 0.5f;

                _cc.Move((strafe + correction).normalized * circleSpeed * SpeedMult * Time.deltaTime);
            }
        }

        // Gravity
        if (_isGrounded && _verticalVelocity < 0f) _verticalVelocity = -2f;
        _verticalVelocity += gravity * Time.deltaTime;
        _cc.Move(new Vector3(0f, _verticalVelocity, 0f) * Time.deltaTime);
    }

    // ─────────────────────────────────────────────────────────────
    //  ATTACK: Single Stab
    //  The classic — but wind-up shortens as aggression grows,
    //  making it harder to read at full rage.
    // ─────────────────────────────────────────────────────────────

    IEnumerator SingleStabRoutine()
    {
        _isAttacking         = true;
        _attackCooldownTimer = CurrentCooldown;

        yield return StartCoroutine(LockOnRoutine(0.15f));
        yield return StartCoroutine(WindupRoutine(CurrentWindup));
        yield return new WaitForSeconds(0.08f);
        yield return StartCoroutine(DoLunge(CurrentLunge, lungeDuration));

        // If the spike tip's collider hit the player, SpikeKill handles the kill.
        // We always count this as a "miss" for charge-forcing purposes —
        // if the player WAS hit, they're dead and it doesn't matter.
        _consecutiveMisses++;

        yield return StartCoroutine(DoRecover(0.3f));

        _isAttacking = false;
        _state       = State.Chase;
    }

    // ─────────────────────────────────────────────────────────────
    //  ATTACK: Stab Combo
    //  2 rapid stabs at mid-aggression, 3 at max.
    //  Each stab re-faces the player — he tracks you.
    // ─────────────────────────────────────────────────────────────

    IEnumerator StabComboRoutine()
    {
        _isAttacking         = true;
        _attackCooldownTimer = CurrentCooldown;

        int stabs = Aggression >= 0.8f ? 3 : 2;

        for (int i = 0; i < stabs; i++)
        {
            // Re-face player between each stab
            yield return StartCoroutine(LockOnRoutine(0.08f));

            // Quick wind-up (shorter than single stab — rapid-fire)
            float elapsed = 0f;
            while (elapsed < 0.13f)
            {
                elapsed += Time.deltaTime;
                if (leftWing) leftWing.localRotation =
                    Quaternion.Slerp(_spikeCarryRot, _spikeWindupRot, elapsed / 0.13f);
                yield return null;
            }

            // Store combo lunge origin for retract
            Vector3 comboOrigin = transform.position;
            yield return StartCoroutine(DoLunge(CurrentLunge * 0.85f, lungeDuration * 0.85f));

            _consecutiveMisses++;

            // Quick retract back to pre-lunge position
            Vector3 retractFrom  = transform.position;
            float   retractTimer = 0f;
            while (retractTimer < 0.15f)
            {
                retractTimer += Time.deltaTime;
                float t = Mathf.SmoothStep(0f, 1f, retractTimer / 0.15f);
                transform.position = Vector3.Lerp(retractFrom, comboOrigin, t);
                if (leftWing) leftWing.localRotation =
                    Quaternion.Slerp(leftWing.localRotation, _spikeCarryRot, t);
                yield return null;
            }

            // Tiny pause between hits — just enough to feel them individually
            if (i < stabs - 1)
                yield return new WaitForSeconds(0.08f);
        }

        _isAttacking = false;
        _state       = State.Chase;
    }

    // ─────────────────────────────────────────────────────────────
    //  ATTACK: Feint
    //  Full wind-up, then holds it to bait the dodge.
    //  After the hesitate, sidesteps and strikes from a new angle.
    //  Punishes players who react to the wind-up animation.
    // ─────────────────────────────────────────────────────────────

    IEnumerator FeintRoutine()
    {
        _isAttacking         = true;
        _attackCooldownTimer = CurrentCooldown;

        yield return StartCoroutine(LockOnRoutine(0.15f));

        // Wind-up looks identical to a single stab — intentional
        yield return StartCoroutine(WindupRoutine(0.22f));

        // Hesitate — this is the feint. Player has probably dodged by now.
        yield return new WaitForSeconds(feintHesitateTime);

        // Sidestep to a new angle before committing
        float   sideDir   = Random.value < 0.5f ? 1f : -1f;
        Vector3 sideStart = transform.position;
        Vector3 sideEnd   = sideStart + transform.right * sideDir * 0.65f;
        float   elapsed   = 0f;
        while (elapsed < 0.12f)
        {
            elapsed += Time.deltaTime;
            transform.position = Vector3.Lerp(sideStart, sideEnd,
                Mathf.SmoothStep(0f, 1f, elapsed / 0.12f));
            FacePlayer();
            yield return null;
        }

        // NOW he strikes — slightly longer lunge as a reward for the setup
        yield return StartCoroutine(DoLunge(CurrentLunge * 1.2f, lungeDuration));

        _consecutiveMisses++;

        yield return StartCoroutine(DoRecover(0.3f));

        _isAttacking = false;
        _state       = State.Chase;
    }

    // ─────────────────────────────────────────────────────────────
    //  ATTACK: Charge
    //  Unlocks at high aggression, or forced after too many misses.
    //  He COMMITS to a direction on launch — readable but terrifying.
    //  After the charge: a stumble pause. Breathe. Then he's back.
    // ─────────────────────────────────────────────────────────────

    IEnumerator ChargeRoutine()
    {
        _isAttacking         = true;
        _attackCooldownTimer = CurrentCooldown * 1.4f; // big commitment, longer cooldown
        _consecutiveMisses   = 0;

        // Wind-up: rear back and lock eyes — this is the tell
        // The player has chargeWindupTime seconds to get out of the way
        PlaySound(chargeRoarSFX);
        float elapsed = 0f;
        while (elapsed < chargeWindupTime)
        {
            elapsed += Time.deltaTime;
            FacePlayer();
            if (body) body.localRotation = Quaternion.Slerp(body.localRotation,
                Quaternion.Euler(-bodyRunLean * 2.5f, 0f, 0f), Time.deltaTime * 5f);
            if (leftWing) leftWing.localRotation = Quaternion.Slerp(leftWing.localRotation,
                _spikeWindupRot, Time.deltaTime * 8f);
            yield return null;
        }

        // Direction locks here — he commits. Dodgeable. Barely.
        Vector3 chargeDir = transform.forward;
        elapsed = 0f;

        while (elapsed < chargeDuration)
        {
            elapsed += Time.deltaTime;
            _cc.Move(chargeDir * chargeSpeed * Time.deltaTime);

            // SpikeKill's trigger collider handles the kill if the spike tip reaches the player

            // Gravity still applies mid-charge
            if (_isGrounded && _verticalVelocity < 0f) _verticalVelocity = -2f;
            _verticalVelocity += gravity * Time.deltaTime;
            _cc.Move(new Vector3(0f, _verticalVelocity, 0f) * Time.deltaTime);

            yield return null;
        }

        // Stumble — brief recovery. The player's one moment of relief.
        yield return new WaitForSeconds(0.45f);

        _isAttacking = false;
        _state       = State.Chase;
    }

    // ─────────────────────────────────────────────────────────────
    //  Orbit then commit
    // ─────────────────────────────────────────────────────────────

    IEnumerator CircleThenAttack(AttackType attack)
    {
        EnterCircle();
        float circleFor = Random.Range(circleTimeMin * 0.4f, circleTimeMax * 0.5f);
        yield return new WaitForSeconds(circleFor);
        if (!_isAttacking)
            LaunchAttack(attack);
    }

    // ─────────────────────────────────────────────────────────────
    //  Shared attack building blocks
    // ─────────────────────────────────────────────────────────────

    /// Smoothly snaps to face the player for <duration> seconds.
    IEnumerator LockOnRoutine(float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            FacePlayer();
            yield return null;
        }
    }

    /// Pulls the spike back into wind-up pose over <duration> seconds.
    IEnumerator WindupRoutine(float duration)
    {
        PlaySound(stabWindupSFX);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = elapsed / duration;
            if (leftWing) leftWing.localRotation =
                Quaternion.Slerp(_spikeCarryRot, _spikeWindupRot, t);
            if (head) head.localRotation = Quaternion.Slerp(head.localRotation,
                _headRest * Quaternion.Euler(-headIdleLook, 0f, 0f), Time.deltaTime * 12f);
            yield return null;
        }
    }

    /// Lunges forward over <duration> seconds.
    /// The spike tip's SpikeKill trigger collider handles the actual kill —
    /// this method only moves the body.
    IEnumerator DoLunge(float distance, float duration)
    {
        PlaySound(stabLungeSFX);
        _lungeOrigin  = transform.position;
        Vector3 target = _lungeOrigin + transform.forward * distance;
        float elapsed  = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / duration);
            transform.position = Vector3.Lerp(_lungeOrigin, target, t);

            if (leftWing != null && _player != null)
                AimSpikeAtPlayer(_player.position);

            yield return null;
        }
    }

    /// Pulls back from the end of the lunge to _lungeOrigin.
    IEnumerator DoRecover(float duration)
    {
        Vector3 recoverStart = transform.position;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / duration);
            transform.position = Vector3.Lerp(recoverStart, _lungeOrigin, t);
            if (leftWing) leftWing.localRotation =
                Quaternion.Slerp(leftWing.localRotation, _spikeCarryRot, t);
            yield return null;
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────

    void FacePlayer()
    {
        if (_player == null) return;
        Vector3 toPlayer = _player.position - transform.position;
        toPlayer.y = 0f;
        if (toPlayer.sqrMagnitude > 0.01f)
            transform.rotation = Quaternion.Slerp(transform.rotation,
                Quaternion.LookRotation(toPlayer.normalized),
                Time.deltaTime * 20f);
    }

    /// Rotates leftWing so the spike tip points toward targetPos.
    /// Uses handle→tip as the pointing axis — works regardless of spike mesh orientation.
    void AimSpikeAtPlayer(Vector3 targetPos)
    {
        if (leftWing == null) return;

        if (spikeHandle == null || spikeTip == null)
        {
            Vector3 fallback = (targetPos - leftWing.position).normalized;
            if (fallback.sqrMagnitude > 0.01f)
                leftWing.rotation = Quaternion.LookRotation(fallback);
            return;
        }

        Vector3 currentDir = (spikeTip.position - spikeHandle.position).normalized;
        Vector3 desiredDir = (targetPos - spikeHandle.position).normalized;

        if (currentDir.sqrMagnitude < 0.01f || desiredDir.sqrMagnitude < 0.01f) return;

        Quaternion aimDelta = Quaternion.FromToRotation(currentDir, desiredDir);
        leftWing.rotation = Quaternion.Slerp(leftWing.rotation,
            aimDelta * leftWing.rotation, Time.deltaTime * 35f);
    }

    // ─────────────────────────────────────────────────────────────
    //  ATTACK: Jump Attack
    //  Triggered when the player is airborne. Chickus leaps upward
    //  toward the player's position and thrusts the spike mid-air.
    //  Direction locks at the moment of leap — readable but fast.
    // ─────────────────────────────────────────────────────────────

    IEnumerator JumpAttackRoutine()
    {
        _isAttacking         = true;
        _attackCooldownTimer = CurrentCooldown;
        _jumpCooldownTimer   = jumpCooldown * 1.5f;

        // Brief lock-on and wind-up before leaping
        yield return StartCoroutine(LockOnRoutine(0.12f));
        PlaySound(stabWindupSFX);

        float windElapsed = 0f;
        while (windElapsed < 0.15f)
        {
            windElapsed += Time.deltaTime;
            if (leftWing) leftWing.localRotation =
                Quaternion.Slerp(_spikeCarryRot, _spikeWindupRot, windElapsed / 0.15f);
            if (head) head.localRotation = Quaternion.Slerp(head.localRotation,
                _headRest * Quaternion.Euler(-headIdleLook, 0f, 0f), Time.deltaTime * 14f);
            yield return null;
        }

        // LEAP — direction toward player, locked at this moment
        if (_player != null) FacePlayer();
        Vector3 toPlayerWorld = _player != null
            ? (_player.position - transform.position).normalized
            : transform.forward;

        // Horizontal velocity toward player, vertical velocity upward
        float hSpeed = CurrentSpeed * 1.4f;
        _verticalVelocity = jumpForce * 1.1f;
        PlaySound(jumpSFX);

        // Thrust sound fires as he peaks
        bool thrustPlayed = false;

        // Mid-air — keep moving toward player, let gravity do its thing
        float airTime = 0f;
        float maxAirTime = 0.7f;   // safety cap

        while (!_isGrounded && airTime < maxAirTime)
        {
            airTime += Time.deltaTime;

            // Horizontal thrust toward where player was at leap time
            _cc.Move(toPlayerWorld * hSpeed * Time.deltaTime);

            // Aim spike at player mid-air
            if (leftWing != null && _player != null)
                AimSpikeAtPlayer(_player.position);

            // Play thrust sound at the arc peak (when vertical velocity crosses zero)
            if (!thrustPlayed && _verticalVelocity <= 0f)
            {
                thrustPlayed = true;
                PlaySound(stabLungeSFX);
            }

            // Gravity
            _verticalVelocity += gravity * Time.deltaTime;
            _cc.Move(new Vector3(0f, _verticalVelocity, 0f) * Time.deltaTime);

            yield return null;
        }

        // Brief recovery after landing
        yield return new WaitForSeconds(0.25f);

        if (leftWing) leftWing.localRotation =
            Quaternion.Slerp(leftWing.localRotation, _spikeCarryRot, 1f);

        _consecutiveMisses++;
        _isAttacking = false;
        _state       = State.Chase;
    }

    // ─────────────────────────────────────────────────────────────
    //  Audio helper
    // ─────────────────────────────────────────────────────────────

    void PlaySound(AudioClip clip)
    {
        if (audioSource != null && clip != null)
            audioSource.PlayOneShot(clip);
    }

    // ─────────────────────────────────────────────────────────────
    //  Animation
    // ─────────────────────────────────────────────────────────────

    void HandleAnimation()
    {
        bool isMoving = _state == State.Chase || _state == State.Circle;

        if (isMoving)
        {
            // Leg and bob timers speed up with aggression — he moves with more fury
            _legTimer     += Time.deltaTime * legSwingSpeed * SpeedMult;
            _bodyBobTimer += Time.deltaTime * bodyBobSpeed  * SpeedMult;

            // Footsteps — only while grounded and chasing
            if (_isGrounded)
            {
                _footstepTimer -= Time.deltaTime * SpeedMult;
                if (_footstepTimer <= 0f)
                {
                    PlaySound(footstepSFX);
                    _footstepTimer = footstepInterval;
                }
            }
        }

        _idleLookTimer += Time.deltaTime;

        AnimateLegs(isMoving);
        AnimateBody(isMoving);
        AnimateWings();
        AnimateHead(isMoving);
    }

    void AnimateLegs(bool isMoving)
    {
        if (!rightLeg || !leftLeg) return;

        if (isMoving)
        {
            float rAngle = Mathf.Sin(_legTimer)            * legSwingAngle;
            float lAngle = Mathf.Sin(_legTimer + Mathf.PI) * legSwingAngle;
            rightLeg.localRotation = _rightLegRest * Quaternion.Euler(rAngle, 0f, 0f);
            leftLeg.localRotation  = _leftLegRest  * Quaternion.Euler(lAngle, 0f, 0f);
        }
        else
        {
            rightLeg.localRotation = Quaternion.Slerp(rightLeg.localRotation, _rightLegRest, Time.deltaTime * 8f);
            leftLeg.localRotation  = Quaternion.Slerp(leftLeg.localRotation,  _leftLegRest,  Time.deltaTime * 8f);
        }
    }

    void AnimateBody(bool isMoving)
    {
        if (!body) return;

        float bobY = isMoving
            ? Mathf.Abs(Mathf.Sin(_bodyBobTimer)) * bodyBobHeight
            : 0f;

        body.localPosition = Vector3.Lerp(body.localPosition,
            _bodyRestPos + new Vector3(0f, bobY, 0f), Time.deltaTime * 15f);

        float lean = isMoving ? bodyRunLean : 0f;
        body.localRotation = Quaternion.Slerp(body.localRotation,
            Quaternion.Euler(lean, 0f, 0f), Time.deltaTime * 7f);

        body.localScale = Vector3.Lerp(body.localScale, _bodyRestScale, Time.deltaTime * 10f);
    }

    void AnimateWings()
    {
        // Left wing returns to carry pose when not mid-attack
        if (!_isAttacking && leftWing)
            leftWing.localRotation = Quaternion.Slerp(leftWing.localRotation,
                _spikeCarryRot, Time.deltaTime * 8f);

        // Right wing: subtle drift — gets more agitated as aggression rises
        if (rightWing)
        {
            float driftSpeed = Mathf.Lerp(1.6f, 3.5f, Aggression);
            float drift = Mathf.Sin(Time.time * driftSpeed) * rightWingIdleDrift;
            rightWing.localRotation = Quaternion.Slerp(rightWing.localRotation,
                _rightWingRest * Quaternion.Euler(0f, 0f, drift), Time.deltaTime * 6f);
        }
    }

    void AnimateHead(bool isMoving)
    {
        if (!head || _isAttacking) return;

        Quaternion targetRot;
        if (isMoving)
        {
            // Nod intensity increases with aggression — angrier, more determined
            float intensity = Mathf.Lerp(1f, 1.6f, Aggression);
            float nod = Mathf.Sin(_bodyBobTimer) * headNodAngle * intensity;
            targetRot = _headRest * Quaternion.Euler(nod + 8f, 0f, 0f);
        }
        else
        {
            // Idle: slow suspicious scan
            float scan = Mathf.Sin(_idleLookTimer * 0.7f) * headIdleLook;
            targetRot  = _headRest * Quaternion.Euler(0f, scan, 0f);
        }

        head.localRotation = Quaternion.Slerp(head.localRotation, targetRot, Time.deltaTime * 6f);
    }

    // ─────────────────────────────────────────────────────────────
    //  Editor gizmos
    // ─────────────────────────────────────────────────────────────

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        // Detection radius — yellow
        Gizmos.color = new Color(1f, 1f, 0f, 0.2f);
        Gizmos.DrawWireSphere(transform.position, detectionRadius);

        // Lose radius — orange
        Gizmos.color = new Color(1f, 0.5f, 0f, 0.15f);
        Gizmos.DrawWireSphere(transform.position, loseRadius);

        // Attack range — red
        Gizmos.color = new Color(1f, 0.1f, 0.1f, 0.3f);
        Gizmos.DrawWireSphere(transform.position, attackRange);

        // Charge hit radius — purple
        Gizmos.color = new Color(0.6f, 0f, 1f, 0.2f);
        Gizmos.DrawWireSphere(transform.position, chargeHitRadius);
    }
#endif
}