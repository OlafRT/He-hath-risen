using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

/// <summary>
/// OilSink — Attach to a Trigger Collider on or just below the oil surface.
///
/// When the chick enters the trigger:
///   1. Input and physics are frozen — we take full control.
///   2. Splash and scream sounds play.
///   3. PHASE 1 — Panic: wings thrash upward, legs kick wildly, head cranes up screaming.
///   4. PHASE 2 — Exhaustion: movements slow and weaken. One wing rises in a final
///      desperate reach (the T2 moment). Then it too goes still.
///   5. PHASE 3 — Submerge: the chick sinks below the surface, screen fades to black,
///      next scene loads.
///
/// NOTE: This is NOT a death — Die() is never called. The ChickController is simply
/// disabled for the duration so we can drive the limbs ourselves. Re-enable it
/// (or just load a fresh scene) when you're done.
///
/// SETUP:
///   - Place this script on an invisible trigger volume at the oil surface level.
///   - Assign all limb transforms (Body, RightLeg, etc.) — same refs as ChickController.
///   - Add a CanvasGroup on a full-screen black Image (raycast off) for the fade.
///   - Set Next Scene Name to the scene you want to load after submersion.
/// </summary>
public class OilSink : MonoBehaviour
{
    // ─────────────────────────────────────────────────────────────
    //  Inspector
    // ─────────────────────────────────────────────────────────────

    [Header("── Transforms ──────────────────────")]
    [Tooltip("Same transforms as ChickController — drag them all in")]
    public Transform body;
    public Transform rightLeg;
    public Transform leftLeg;
    public Transform rightWing;
    public Transform leftWing;
    public Transform head;

    [Header("── Scene Loading ───────────────────")]
    [Tooltip("Exact name of the scene to load once fully submerged")]
    public string nextSceneName;

    [Header("── Phase Timing ────────────────────")]
    [Tooltip("How long the chick thrashes in full panic before tiring")]
    public float panicDuration      = 3.8f;
    [Tooltip("How long the exhaustion / reaching phase lasts")]
    public float exhaustionDuration = 2.6f;
    [Tooltip("How long the final submersion takes before the scene loads")]
    public float submergeDuration   = 2.0f;

    [Header("── Sink Speed ──────────────────────")]
    [Tooltip("Units/sec downward during panic — slow, still fighting")]
    public float panicSinkSpeed      = 0.12f;
    [Tooltip("Units/sec during exhaustion — losing the battle")]
    public float exhaustionSinkSpeed = 0.28f;
    [Tooltip("Units/sec during final submersion — no more fight left")]
    public float submergeSinkSpeed   = 0.65f;

    [Header("── Panic Animation ─────────────────")]
    [Tooltip("How fast the wings stroke upward while panicking")]
    public float panicWingSpeed      = 6.0f;
    [Tooltip("How large the upward wing stroke is (degrees)")]
    public float panicWingAngle      = 72f;
    [Tooltip("How fast the legs kick")]
    public float panicLegSpeed       = 8.5f;
    [Tooltip("Kick amplitude (degrees)")]
    public float panicLegAngle       = 55f;

    [Header("── The Reach (T2 moment) ───────────")]
    [Tooltip("Which phase (0-1) of exhaustion the reaching wing starts extending")]
    [Range(0f, 1f)]
    public float reachStartPhase     = 0.45f;
    [Tooltip("How far the wing rotates upward for The Reach (degrees on Z axis)")]
    public float reachWingAngle      = 105f;
    [Tooltip("How slowly the wing drifts up — lower = more agonizing")]
    public float reachSpeed          = 2.5f;

    [Header("── Fade ────────────────────────────")]
    [Tooltip("CanvasGroup on a full-screen black Image — fades the scene to black")]
    public CanvasGroup fadeOverlay;
    [Tooltip("How long the fade-to-black takes")]
    public float fadeDuration        = 1.4f;
    [Tooltip("How long after the fade completes before loading the scene")]
    public float postFadeDelay       = 0.3f;

    [Header("── Audio ───────────────────────────")]
    public AudioSource audioSource;
    [Tooltip("Big dramatic scream on hitting the oil")]
    public AudioClip screamSFX;
    [Tooltip("Wet splash impact")]
    public AudioClip splashSFX;
    [Tooltip("Sad little defeated sound as they go fully under")]
    public AudioClip finalGulpSFX;

    // ─────────────────────────────────────────────────────────────
    //  Private
    // ─────────────────────────────────────────────────────────────

    bool _triggered;

    // Rest rotations snapshotted from the live chick the moment we take over
    Quaternion _rightLegRest, _leftLegRest;
    Quaternion _rightWingRest, _leftWingRest;
    Quaternion _headRest;
    Quaternion _bodyRestRot;
    Vector3    _bodyRestPos, _bodyRestScale;

    // ─────────────────────────────────────────────────────────────

    void OnTriggerEnter(Collider other)
    {
        if (_triggered) return;

        ChickController hit = other.GetComponentInParent<ChickController>();
        if (hit == null) return;

        _triggered = true;
        StartCoroutine(SinkSequence(hit));
    }

    // ─────────────────────────────────────────────────────────────
    //  Main sequence
    // ─────────────────────────────────────────────────────────────

    IEnumerator SinkSequence(ChickController victim)
    {
        // Snapshot the chick's limb rest poses exactly as they are right now.
        // This lets all our animation targets be relative to whatever pose
        // the chick was in when it hit the oil, rather than T-pose.
        SnapshotRestPoses();

        // ── Freeze the chick's own Update loop and physics ───────
        // We disable ChickController so it stops animating limbs from under us,
        // and disable CharacterController so we control the position manually.
        // We do NOT call Die() — the chick is not dead, just very busy drowning.
        CharacterController cc = victim.GetComponent<CharacterController>();
        victim.enabled = false;
        if (cc) cc.enabled = false;

        // ── Impact sounds ────────────────────────────────────────
        PlaySound(splashSFX);
        yield return new WaitForSeconds(0.08f);
        PlaySound(screamSFX);

        // ────────────────────────────────────────────────────────────────────
        //  PHASE 1 — PANIC
        //  Full thrash. Wings beat upward desperately trying to claw back out.
        //  Legs kick frantically. Head cranes back, screaming at the sky.
        //  The chick sinks slowly — it IS fighting, just not winning.
        // ────────────────────────────────────────────────────────────────────

        float t = 0f;
        while (t < panicDuration)
        {
            t += Time.deltaTime;

            // Slowly losing ground
            victim.transform.position += Vector3.down * panicSinkSpeed * Time.deltaTime;

            // Wings: alternating upward swim-strokes, half a cycle out of phase.
            // Negative Z on the right wing = sweeping upward on this rig.
            if (rightWing)
            {
                float rStroke = Mathf.Sin(t * panicWingSpeed) * panicWingAngle;
                rightWing.localRotation = Quaternion.Slerp(
                    rightWing.localRotation,
                    _rightWingRest * Quaternion.Euler(rStroke * 0.25f, 0f, -rStroke),
                    Time.deltaTime * 14f);
            }
            if (leftWing)
            {
                // Offset by half cycle (+ π) so wings alternate like a desperate breaststroke
                float lStroke = Mathf.Sin(t * panicWingSpeed + Mathf.PI) * panicWingAngle;
                leftWing.localRotation = Quaternion.Slerp(
                    leftWing.localRotation,
                    _leftWingRest * Quaternion.Euler(lStroke * 0.25f, 0f, lStroke),
                    Time.deltaTime * 14f);
            }

            // Legs: frantic alternating kicks, also out of phase
            if (rightLeg)
            {
                float rKick = Mathf.Sin(t * panicLegSpeed) * panicLegAngle;
                rightLeg.localRotation = Quaternion.Slerp(
                    rightLeg.localRotation,
                    _rightLegRest * Quaternion.Euler(rKick, 0f, Mathf.Sin(t * 4.3f) * 18f),
                    Time.deltaTime * 16f);
            }
            if (leftLeg)
            {
                float lKick = Mathf.Sin(t * panicLegSpeed + 1.7f) * panicLegAngle;
                leftLeg.localRotation = Quaternion.Slerp(
                    leftLeg.localRotation,
                    _leftLegRest * Quaternion.Euler(lKick, 0f, Mathf.Sin(t * 5.1f) * 18f),
                    Time.deltaTime * 16f);
            }

            // Head: thrown back, looking straight up at the sky — desperate, screaming.
            // Shakes side to side as if yelling for help.
            if (head)
            {
                float shake = Mathf.Sin(t * 9.5f) * 14f;
                head.localRotation = Quaternion.Slerp(
                    head.localRotation,
                    _headRest * Quaternion.Euler(-40f, shake, 0f),   // -40 = craned back/up
                    Time.deltaTime * 10f);
            }

            // Body: wobbles and pitches as it struggles — not going down without a fight
            if (body)
            {
                float wobble = Mathf.Sin(t * 4.7f) * 7f;
                body.localRotation = Quaternion.Slerp(
                    body.localRotation,
                    _bodyRestRot * Quaternion.Euler(-8f + wobble * 0.4f, 0f, wobble),
                    Time.deltaTime * 7f);
            }

            yield return null;
        }

        // ────────────────────────────────────────────────────────────────────
        //  PHASE 2 — EXHAUSTION
        //  The fight is leaving. Movements slow and soften.
        //  Right wing rises in a final desperate reach — the T2 moment.
        //  Left wing droops first. Head sags. Legs barely paddle.
        //  Sinking picks up because the resistance is gone.
        // ────────────────────────────────────────────────────────────────────

        t = 0f;
        while (t < exhaustionDuration)
        {
            t += Time.deltaTime;
            float phase   = t / exhaustionDuration;   // 0 → 1 across the exhaustion arc
            float energy  = 1f - phase;               // energy draining away

            victim.transform.position += Vector3.down * exhaustionSinkSpeed * Time.deltaTime;

            // Right wing: the one that REACHES.
            // Before the reach threshold: still stroking, but slow and weak.
            // After the threshold: slowly, agonizingly extends straight up.
            if (rightWing)
            {
                if (phase < reachStartPhase)
                {
                    // Weak, slowing strokes
                    float rStroke = Mathf.Sin(t * panicWingSpeed * 0.45f) * panicWingAngle * energy;
                    rightWing.localRotation = Quaternion.Slerp(
                        rightWing.localRotation,
                        _rightWingRest * Quaternion.Euler(rStroke * 0.25f, 0f, -rStroke),
                        Time.deltaTime * 7f);
                }
                else
                {
                    // THE REACH — one last attempt to grab something, anything.
                    // The wing extends slowly upward. It won't be enough.
                    Quaternion reachTarget = _rightWingRest * Quaternion.Euler(0f, -15f, -reachWingAngle);
                    rightWing.localRotation = Quaternion.Slerp(
                        rightWing.localRotation,
                        reachTarget,
                        Time.deltaTime * reachSpeed);
                }
            }

            // Left wing: droops to a limp defeated hang while the right reaches
            if (leftWing)
            {
                float lStroke = (phase < 0.6f)
                    ? Mathf.Sin(t * panicWingSpeed * 0.45f + Mathf.PI) * panicWingAngle * energy
                    : 0f;
                Quaternion lTarget = (phase < 0.6f)
                    ? _leftWingRest * Quaternion.Euler(lStroke * 0.25f, 0f, lStroke)
                    : _leftWingRest * Quaternion.Euler(18f, 0f, 32f);   // limp hang
                leftWing.localRotation = Quaternion.Slerp(
                    leftWing.localRotation, lTarget,
                    Time.deltaTime * (phase < 0.6f ? 7f : 3.5f));
            }

            // Legs: slow to weak, tired, barely a twitch by the end
            if (rightLeg)
            {
                float rKick = Mathf.Sin(t * panicLegSpeed * 0.4f) * panicLegAngle * 0.5f * energy;
                rightLeg.localRotation = Quaternion.Slerp(
                    rightLeg.localRotation,
                    _rightLegRest * Quaternion.Euler(rKick, 0f, 0f),
                    Time.deltaTime * 6f);
            }
            if (leftLeg)
            {
                float lKick = Mathf.Sin(t * panicLegSpeed * 0.4f + 1.7f) * panicLegAngle * 0.5f * energy;
                leftLeg.localRotation = Quaternion.Slerp(
                    leftLeg.localRotation,
                    _leftLegRest * Quaternion.Euler(lKick, 0f, 0f),
                    Time.deltaTime * 6f);
            }

            // Head: slowly lowers from looking-up to hanging forward.
            // The transition from hope to defeat, expressed in neck angle.
            if (head)
            {
                float headPitch = Mathf.Lerp(-40f, 28f, Mathf.SmoothStep(0f, 1f, phase));
                head.localRotation = Quaternion.Slerp(
                    head.localRotation,
                    _headRest * Quaternion.Euler(headPitch, 0f, 0f),
                    Time.deltaTime * 3.5f);
            }

            // Body: stills itself, settles into quiet acceptance
            if (body)
            {
                body.localRotation = Quaternion.Slerp(
                    body.localRotation, _bodyRestRot, Time.deltaTime * 2.5f);
            }

            yield return null;
        }

        // ────────────────────────────────────────────────────────────────────
        //  PHASE 3 — SUBMERGE
        //  It's over. No more fight. Just the slow pull under the surface.
        //  The reaching wing drifts back down as the chick disappears.
        //  Fade to black. Load the next scene.
        // ────────────────────────────────────────────────────────────────────

        PlaySound(finalGulpSFX);

        // Kick off the fade in parallel — it runs alongside the sink
        StartCoroutine(FadeToBlack());

        t = 0f;
        while (t < submergeDuration)
        {
            t += Time.deltaTime;

            // Sinking fast now — the oil has won
            victim.transform.position += Vector3.down * submergeSinkSpeed * Time.deltaTime;

            // The reaching wing slowly gives in and droops down
            if (rightWing)
            {
                Quaternion droop = _rightWingRest * Quaternion.Euler(15f, 0f, 42f);
                rightWing.localRotation = Quaternion.Slerp(
                    rightWing.localRotation, droop, Time.deltaTime * 1.8f);
            }

            // Body tilts slightly forward as it sinks — the final slump
            if (body)
            {
                body.localRotation = Quaternion.Slerp(
                    body.localRotation,
                    _bodyRestRot * Quaternion.Euler(15f, 0f, 0f),
                    Time.deltaTime * 2f);
            }

            yield return null;
        }

        // Wait for the fade to fully complete before switching scenes
        yield return new WaitUntil(() => fadeOverlay == null || fadeOverlay.alpha >= 1f);
        yield return new WaitForSeconds(postFadeDelay);

        SceneManager.LoadScene(nextSceneName);
    }

    // ─────────────────────────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────────────────────────

    void SnapshotRestPoses()
    {
        if (body)      { _bodyRestRot = body.localRotation; _bodyRestPos = body.localPosition; _bodyRestScale = body.localScale; }
        if (rightLeg)  _rightLegRest  = rightLeg.localRotation;
        if (leftLeg)   _leftLegRest   = leftLeg.localRotation;
        if (rightWing) _rightWingRest = rightWing.localRotation;
        if (leftWing)  _leftWingRest  = leftWing.localRotation;
        if (head)      _headRest      = head.localRotation;
    }

    IEnumerator FadeToBlack()
    {
        if (fadeOverlay == null) yield break;

        float elapsed = 0f;
        fadeOverlay.alpha = 0f;

        while (elapsed < fadeDuration)
        {
            elapsed += Time.deltaTime;
            fadeOverlay.alpha = Mathf.Clamp01(elapsed / fadeDuration);
            yield return null;
        }

        fadeOverlay.alpha = 1f;
    }

    void PlaySound(AudioClip clip)
    {
        if (audioSource != null && clip != null)
            audioSource.PlayOneShot(clip);
    }

    // ─────────────────────────────────────────────────────────────
    //  Editor
    // ─────────────────────────────────────────────────────────────

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        // Draw the trigger volume so you can see exactly where the oil surface is
        Gizmos.color = new Color(0.1f, 0.05f, 0f, 0.5f);
        Gizmos.matrix = transform.localToWorldMatrix;

        Collider col = GetComponent<Collider>();
        if (col is BoxCollider box)
            Gizmos.DrawCube(box.center, box.size);
        else
            Gizmos.DrawCube(Vector3.zero, Vector3.one);
    }
#endif
}
