using UnityEngine;

/// <summary>
/// CorpseFollower — Added dynamically by CorpseManager to any corpse that should
/// move with a spike. Tracks the spike's position and rotation in LateUpdate WITHOUT
/// inheriting its scale, so the corpse is never squished by a spike's transform.
///
/// This replaces the previous SetParent approach entirely.
/// The corpse is never a child of the spike in the hierarchy — it just follows it.
/// </summary>
public class CorpseFollower : MonoBehaviour
{
    Transform  _spike;

    // Scale-free offset stored in spike-local space.
    // Reconstructed each frame as: spikePos + spikeRot * _posOffset
    // No scale involved anywhere.
    Vector3    _posOffset;
    Quaternion _rotOffset;

    /// <summary>
    /// Call immediately after spawning the corpse.
    /// worldPos/worldRot are the corpse's desired world position and rotation.
    /// </summary>
    public void Init(Transform spike, Vector3 worldPos, Quaternion worldRot)
    {
        _spike     = spike;
        _posOffset = Quaternion.Inverse(spike.rotation) * (worldPos - spike.position);
        _rotOffset = Quaternion.Inverse(spike.rotation) * worldRot;
    }

    void LateUpdate()
    {
        if (_spike == null) return;

        // Recompute world transform from spike rotation only — scale is never touched
        transform.position = _spike.position + _spike.rotation * _posOffset;
        transform.rotation = _spike.rotation * _rotOffset;
    }
}
