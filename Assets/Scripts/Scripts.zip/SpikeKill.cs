using System.Collections;
using UnityEngine;
 
/// <summary>
/// SpikeKill — Attach to the spike tip's Trigger Collider.
///
/// HIERARCHY EXPECTED:
///   Spike (root)
///     └── Tip  ← this script + a small Trigger Collider (sphere/capsule) here
/// </summary>
public class SpikeKill : MonoBehaviour
{
    [Header("── References ─────────────────────")]
    [Tooltip("The ChickController in the scene")]
    public ChickController chick;
    [Tooltip("The DeathScreen in the scene")]
    public DeathScreen deathScreen;
 
    [Header("── Impalement ──────────────────────")]
    [Tooltip("Shifts the chick's pivot DOWN along its own up-axis so the body CENTER " +
             "sits at the spike tip, not the feet. The chick pivot is at its feet, so " +
             "without this the body floats above/outside the tip. " +
             "Tune until the body looks centered — 0.3 to 0.5 is a good starting range.")]
    public float bodyTipOffset       = 0.35f;
    [Tooltip("Base distance the chick slides along the spike shaft")]
    public float slideDistance       = 0.9f;
    [Tooltip("Random extra slide added each time (keeps corpses varied)")]
    public float slideRandomRange    = 0.35f;
    [Tooltip("How long the slide takes")]
    public float slideDuration       = 0.45f;
    [Tooltip("Random Y rotation range applied to the corpse (degrees)")]
    public float rotationRandomRange = 25f;
    [Tooltip("How long to wait after sliding before showing the death screen")]
    public float deathScreenDelay    = 1.1f;
 
    [Header("── Particles ───────────────────────")]
    [Tooltip("A ParticleSystem child of this GameObject for the blood burst")]
    public ParticleSystem bloodBurst;
 
    [Header("── Audio ───────────────────────────")]
    public AudioSource audioSource;
    public AudioClip   impaleSFX;
    public AudioClip   sadSFX;
 
    // ─────────────────────────────────────────────────────────────

    static bool s_dead;

    void Awake()
    {
        s_dead = false;
    }
 
    void OnTriggerEnter(Collider other)
    {
        if (s_dead) return;
 
        ChickController hit = other.GetComponentInParent<ChickController>();
        if (hit == null) return;
 
        s_dead = true;
        StartCoroutine(ImpalementSequence(hit));
    }
 
    IEnumerator ImpalementSequence(ChickController victim)
    {
        // ── 1. Kill movement immediately ────────────────────────
        victim.Die();

        Transform spikeRoot = transform.parent != null ? transform.parent : transform;

        // Shaft direction: tip → root, stored in spike-local space so it stays
        // correct if the spike rotates mid-slide (e.g. ChickusMaximus aiming)
        Vector3 initialSlideDir = (spikeRoot.position - transform.position).normalized;
        if (initialSlideDir.sqrMagnitude < 0.01f) initialSlideDir = Vector3.down;
        Vector3 slideDirLocal = Quaternion.Inverse(spikeRoot.rotation) * initialSlideDir;

        // ── 2. Set rotation first, then snap ────────────────────
        // Rotation is set before position so victim.transform.up is correct
        // when we compute the body-center offset below.
        float randomYRot = Random.Range(-rotationRandomRange, rotationRandomRange);
        Vector3 fwd = victim.transform.forward;
        fwd.y = 0f;
        if (fwd.sqrMagnitude > 0.01f)
            victim.transform.rotation = Quaternion.LookRotation(fwd.normalized)
                * Quaternion.Euler(0f, randomYRot, 0f);

        // Body-center offset — applied along the chick's OWN up axis, NOT the spike shaft.
        //
        // The chick pivot is at its feet. Without this offset, the feet sit at the spike
        // tip and the body visually hovers outside. We move the pivot DOWN by bodyTipOffset
        // so the body center (which is above the pivot) aligns with the tip instead.
        //
        // This is perpendicular to the shaft, so it has no effect on slide distance —
        // it purely repositions the body mass onto the tip.
        Vector3 bodyUpOffset = victim.transform.up * bodyTipOffset;

        // Snap feet to tip, then pull down so body center is at tip
        victim.transform.position = transform.position - bodyUpOffset;

        // Store rotation offset from spike so corpse co-rotates during slide
        Quaternion rotOffsetFromSpike = Quaternion.Inverse(spikeRoot.rotation)
                                        * victim.transform.rotation;

        // ── 3. Blood burst ───────────────────────────────────────
        if (bloodBurst != null)
        {
            bloodBurst.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            bloodBurst.Play();
        }

        PlaySound(impaleSFX);

        // ── 4. Slide along the spike shaft ───────────────────────
        // transform.position (the Tip child) reflects the spike's live world position
        // each frame, so on moving spikes the slide stays locked to the shaft.
        //
        // The body offset is kept constant throughout — it's a perpendicular
        // correction, independent of the along-shaft slide progress.
        float thisSlideDist = slideDistance + Random.Range(0f, slideRandomRange);

        float elapsed = 0f;
        while (elapsed < slideDuration)
        {
            elapsed += Time.deltaTime;
            float t = Mathf.SmoothStep(0f, 1f, elapsed / slideDuration);

            Vector3    tipNow = transform.position;
            Vector3    dirNow = (spikeRoot.rotation * slideDirLocal).normalized;
            Quaternion rotNow = spikeRoot.rotation * rotOffsetFromSpike;

            // body offset re-derived from current rotation so it stays correct
            // if the spike (and thus the corpse) is rotating during the slide
            Vector3 currentBodyOffset = rotNow * Vector3.up * bodyTipOffset;

            victim.transform.position = tipNow - currentBodyOffset + dirNow * (thisSlideDist * t);
            victim.transform.rotation = rotNow;

            yield return null;
        }

        // Final settled position
        {
            Vector3    tipFinal = transform.position;
            Vector3    dirFinal = (spikeRoot.rotation * slideDirLocal).normalized;
            Quaternion rotFinal = spikeRoot.rotation * rotOffsetFromSpike;
            Vector3    finalBodyOffset = rotFinal * Vector3.up * bodyTipOffset;

            victim.transform.position = tipFinal - finalBodyOffset + dirFinal * thisSlideDist;
            victim.transform.rotation = rotFinal;
        }

        // ── 5. Hide victim — corpse prefab takes over the visual ─
        foreach (Renderer r in victim.GetComponentsInChildren<Renderer>())
            r.enabled = false;

        // ── 6. Snapshot and save corpse ──────────────────────────
        if (CorpseManager.Instance != null)
            CorpseManager.Instance.RegisterCorpse(SnapshotCorpse(victim), spikeRoot);

        // ── 7. Sad sound after settling ──────────────────────────
        yield return new WaitForSeconds(0.15f);
        PlaySound(sadSFX);
 
        // ── 8. Death screen ──────────────────────────────────────
        yield return new WaitForSeconds(deathScreenDelay);
 
        if (deathScreen != null)
            deathScreen.Show();
    }
 
    void PlaySound(AudioClip clip)
    {
        if (audioSource != null && clip != null)
            audioSource.PlayOneShot(clip);
    }

    CorpseData SnapshotCorpse(ChickController victim)
    {
        Transform root = victim.transform;
        Transform body = root.Find("Body");

        CorpseData d = new CorpseData();
        d.position = new SerializedVector3(root.position);
        d.rotation = new SerializedQuaternion(root.rotation);

        if (body != null)
        {
            d.bodyRot   = new SerializedQuaternion(body.localRotation);
            d.bodyScale = new SerializedVector3(body.localScale);

            d.rightLegRot  = ChildRot(body, "RightLeg");
            d.leftLegRot   = ChildRot(body, "LeftLeg");
            d.rightWingRot = ChildRot(body, "RightWing");
            d.leftWingRot  = ChildRot(body, "LeftWing");
            d.headRot      = ChildRot(body, "Head");
        }

        return d;
    }

    SerializedQuaternion ChildRot(Transform parent, string childName)
    {
        Transform t = parent.Find(childName);
        return new SerializedQuaternion(t != null ? t.localRotation : Quaternion.identity);
    }
 
#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1f, 0.15f, 0.15f, 0.6f);
        Gizmos.DrawWireSphere(transform.position, 0.18f);

        if (transform.parent != null)
        {
            Gizmos.color = new Color(1f, 0.5f, 0f, 0.8f);
            Gizmos.DrawLine(transform.position, transform.parent.position);
        }
    }
#endif
}
