using System;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// SpikeIdentifier — Attach to the ROOT of any spike that should persist corpses
/// across scene reloads. Gives the spike a stable string ID so CorpseManager can
/// find it again after a reload and re-parent the corpse to it.
///
/// SETUP:
///   - Attach to the spike ROOT (the parent of the Tip object that has SpikeKill).
///   - Click "Generate New ID" in the Inspector context menu once — never change
///     it after that, or saved corpses will lose their spike reference.
///   - Every spike in the scene must have a unique ID.
/// </summary>
public class SpikeIdentifier : MonoBehaviour
{
    [SerializeField]
    [Tooltip("Stable unique ID for this spike. Generate once via the context menu — never change it afterwards.")]
    string _id;

    public string Id => _id;

    // ── Static registry — lets CorpseManager look up spikes by ID ────────────
    static readonly Dictionary<string, SpikeIdentifier> s_registry
        = new Dictionary<string, SpikeIdentifier>();

    void OnEnable()
    {
        if (string.IsNullOrEmpty(_id))
        {
            Debug.LogWarning($"[SpikeIdentifier] '{name}' has no ID set. " +
                             "Right-click the component and choose 'Generate New ID'.", this);
            return;
        }
        s_registry[_id] = this;
    }

    void OnDisable()
    {
        if (!string.IsNullOrEmpty(_id))
            s_registry.Remove(_id);
    }

    /// <summary>
    /// Looks up a spike by its saved ID. Returns true and sets <paramref name="spikeTransform"/>
    /// if found and currently active in the scene.
    /// </summary>
    public static bool TryGet(string id, out Transform spikeTransform)
    {
        spikeTransform = null;
        if (string.IsNullOrEmpty(id)) return false;
        if (!s_registry.TryGetValue(id, out SpikeIdentifier found)) return false;
        spikeTransform = found.transform;
        return true;
    }

    // ── Editor helpers ────────────────────────────────────────────────────────
#if UNITY_EDITOR
    [ContextMenu("Generate New ID")]
    void GenerateNewId()
    {
        _id = Guid.NewGuid().ToString();
        UnityEditor.EditorUtility.SetDirty(this);
        Debug.Log($"[SpikeIdentifier] Generated ID for '{name}': {_id}");
    }
#endif
}
