using System.Collections;
using UnityEngine;

/// <summary>
/// FallDeath — A trigger zone placed below the playfield.
/// When the chick falls into it, they panic, the camera freezes in place,
/// and the chick flails into the void before the death screen appears.
///
/// SETUP:
///   - Create an empty GameObject with a large Box Collider set to Is Trigger.
///   - Position it well below the lowest bun — far enough that the fall
///     feels dramatic before the death screen kicks in.
///   - Assign references in the Inspector.
/// </summary>
public class FallDeath : MonoBehaviour
{
    [Header("── References ─────────────────────")]
    public ChickController chick;
    public ChickCamera     chickCamera;
    public DeathScreen     deathScreen;

    [Header("── Audio ───────────────────────────")]
    public AudioSource audioSource;
    [Tooltip("A panicked scream that plays the moment the trigger is hit")]
    public AudioClip   screamSFX;

    [Header("── Timing ──────────────────────────")]
    [Tooltip("How long to watch the chick fall before fading in the death screen")]
    public float deathScreenDelay = 2.2f;

    // ─────────────────────────────────────────────────────────────

    bool _triggered;

    void OnTriggerEnter(Collider other)
    {
        if (_triggered) return;

        ChickController hit = other.GetComponentInParent<ChickController>();
        if (hit == null) return;

        _triggered = true;
        StartCoroutine(FallSequence(hit));
    }

    IEnumerator FallSequence(ChickController victim)
    {
        // Freeze the camera exactly where it is — left behind as chick falls
        if (chickCamera != null)
            chickCamera.Detach();

        // Tell the chick to start flailing and keep falling
        victim.FallDie();

        // Scream!
        if (audioSource != null && screamSFX != null)
            audioSource.PlayOneShot(screamSFX);

        // Let the player watch the fall for a moment
        yield return new WaitForSeconds(deathScreenDelay);

        if (deathScreen != null)
            deathScreen.Show();
    }

#if UNITY_EDITOR
    void OnDrawGizmosSelected()
    {
        Gizmos.color = new Color(1f, 0.4f, 0f, 0.25f);
        BoxCollider bc = GetComponent<BoxCollider>();
        if (bc) Gizmos.DrawCube(transform.position + bc.center, bc.size);
        Gizmos.color = new Color(1f, 0.4f, 0f, 0.7f);
        if (bc) Gizmos.DrawWireCube(transform.position + bc.center, bc.size);
    }
#endif
}

// =============================================================================
//  ADDITIONS NEEDED IN ChickController.cs
// =============================================================================
//
//  // Add alongside _isDead in the private state block:
//  bool _isFallDying;
//
//  // Replace the existing Update() early-out with this:
//  void Update()
//  {
//      if (_isDead && !_isFallDying) return;   // normal death = full freeze
//      if (_isFallDying) { ContinueFalling(); return; }  // fall death = gravity only
//      GatherGroundState();
//      HandleMovement();
//      HandleAnimation();
//  }
//
//  // Keeps gravity running while the chick falls to their doom:
//  void ContinueFalling()
//  {
//      _velocity.y += gravity * Time.deltaTime;
//      _cc.Move(_velocity * Time.deltaTime);
//  }
//
//  // Called by FallDeath:
//  public void FallDie()
//  {
//      if (_isDead) return;
//      _isDead      = true;
//      _isFallDying = true;
//      _velocity.x  = 0f;
//      _velocity.z  = 0f;
//      StartCoroutine(FallFlailRoutine());
//  }
//
//  IEnumerator FallFlailRoutine()
//  {
//      float t = 0f;
//      while (_isFallDying)
//      {
//          t += Time.deltaTime;
//
//          // Legs kick out wildly, out of phase with each other
//          if (rightLeg) rightLeg.localRotation = _rightLegRest *
//              Quaternion.Euler(Mathf.Sin(t * 7.3f) * 50f, 0f, Mathf.Sin(t * 4.1f) * 25f);
//          if (leftLeg)  leftLeg.localRotation  = _leftLegRest *
//              Quaternion.Euler(Mathf.Sin(t * 6.8f + 1.2f) * 50f, 0f, Mathf.Sin(t * 5.3f) * 25f);
//
//          // Wings flap frantically and asymmetrically
//          if (rightWing) rightWing.localRotation = _rightWingRest *
//              Quaternion.Euler(0f, 0f, Mathf.Sin(t * 11f) * 60f);
//          if (leftWing)  leftWing.localRotation  = _leftWingRest *
//              Quaternion.Euler(0f, 0f, Mathf.Sin(t * 9.5f + 0.8f) * 60f);
//
//          // Head snaps around in panic
//          if (head) head.localRotation = _headRest *
//              Quaternion.Euler(Mathf.Sin(t * 8f) * 20f, Mathf.Sin(t * 5.5f) * 30f, 0f);
//
//          // Whole body slowly spins as it falls — sad little helicopter
//          transform.Rotate(0f, 90f * Time.deltaTime, 0f);
//
//          yield return null;
//      }
//  }
//
// =============================================================================
//  ADDITION NEEDED IN ChickCamera.cs
//  Add this method inside the ChickCamera class:
// =============================================================================
//
//  public void Detach()
//  {
//      target = null;   // LateUpdate already guards with "if (!target) return"
//  }
//
// =============================================================================
