using TMPro;
using UnityEngine;

/// <summary>
/// EndScreenUI — Reads the death count from GameStats, displays it, then immediately
/// wipes the PlayerPrefs save so the next run starts at zero.
///
/// SETUP:
///   - Attach to any GameObject in your end/credits scene.
///   - Drag the "You died X times!" TextMeshPro component into Death Count Label.
///   - Customise the format string if you want different wording.
///     Use {0} as the placeholder for the number — e.g. "You died {0} times!"
/// </summary>
public class EndScreenUI : MonoBehaviour
{
    [Header("── UI ──────────────────────────────")]
    [Tooltip("The TextMeshPro that shows the death count line")]
    public TextMeshPro deathCountLabel;

    [Header("── Wording ─────────────────────────")]
    [Tooltip("Use {0} where the number should appear")]
    public string formatString = "You died {0} times!";

    [Tooltip("Text to show if the player died exactly once")]
    public string singleDeathString = "You died 1 time!";

    // ─────────────────────────────────────────────────────────────

    void Start()
    {
        int deaths = GameStats.Instance != null ? GameStats.Instance.Deaths : 0;

        if (deathCountLabel != null)
        {
            deathCountLabel.text = deaths == 1
                ? singleDeathString
                : string.Format(formatString, deaths);
        }

        // Wipe the save now that the run is over.
        // The count is already displayed, so clearing it here means the next
        // time the player launches the game they start fresh at zero.
        if (GameStats.Instance != null)
            GameStats.Instance.Reset();
    }
}
