using UnityEngine;

/// <summary>
/// GameStats — Singleton that persists run statistics across sessions via PlayerPrefs.
/// Deaths accumulate even if the player quits and relaunches — no cheesing the count
/// by closing the game. The save is wiped automatically when the player reaches the
/// end screen, so every new run starts at zero.
///
/// SETUP:
///   - Create an empty GameObject in your first gameplay scene, name it "GameStats",
///     and attach this script. DontDestroyOnLoad carries it into every scene.
///   - Call GameStats.Instance.AddDeath() wherever a death is confirmed
///     (e.g. inside DeathScreen.Show()).
///   - Reset() is called automatically by EndScreenUI after displaying the final count.
///     You can also call it manually from a main-menu "New Game" button if needed.
/// </summary>
public class GameStats : MonoBehaviour
{
    // ── Singleton ─────────────────────────────────────────────────
    public static GameStats Instance { get; private set; }

    const string DEATHS_KEY = "RunDeaths";

    // ── Stats ─────────────────────────────────────────────────────

    /// <summary>Current death count for this run, read straight from PlayerPrefs.</summary>
    public int Deaths => PlayerPrefs.GetInt(DEATHS_KEY, 0);

    // ─────────────────────────────────────────────────────────────

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    // ── Public API ────────────────────────────────────────────────

    /// <summary>Call once each time the player dies.</summary>
    public void AddDeath()
    {
        PlayerPrefs.SetInt(DEATHS_KEY, Deaths + 1);
        PlayerPrefs.Save();
    }

    /// <summary>
    /// Wipes the saved death count so the next run starts at zero.
    /// Called automatically by EndScreenUI after displaying the final score.
    /// </summary>
    public void Reset()
    {
        PlayerPrefs.DeleteKey(DEATHS_KEY);
        PlayerPrefs.Save();
    }
}
