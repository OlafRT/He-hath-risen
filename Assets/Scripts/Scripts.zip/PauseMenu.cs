using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseMenu : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] private GameObject pausePanel;

    [Header("Scenes")]
    [SerializeField] private string mainMenuSceneName = "MainMenu";

    [Header("Input")]
    [SerializeField] private KeyCode toggleKey = KeyCode.Escape;

    [Header("Disable While Paused")]
    [SerializeField] private MonoBehaviour[] disableWhilePaused; // drag camera script(s) here

    private bool isPaused;

    // Cached lists of "things to pause" (we restore to the exact previous state)
    private readonly List<AudioSource> audioSources = new();
    private readonly Dictionary<AudioSource, bool> audioWasPlaying = new();

    private readonly List<ParticleSystem> particleSystems = new();
    private readonly Dictionary<ParticleSystem, bool> particleWasPlaying = new();

    private readonly List<Animator> animators = new();
    private readonly Dictionary<Animator, float> animatorSpeed = new();

    void Awake()
    {
        if (pausePanel) pausePanel.SetActive(false);

        CachePausables();
        SetPaused(false);
    }

    void Update()
    {
        if (Input.GetKeyDown(toggleKey))
        {
            if (isPaused) Resume();
            else Pause();
        }
    }

    void LateUpdate()
    {
        // Reapply every frame so the UI EventSystem can't override us on resume.
        Cursor.visible   = isPaused;
        Cursor.lockState = isPaused ? CursorLockMode.None : CursorLockMode.Locked;
    }

    private void CachePausables()
    {
        // Include inactive objects too, in case some are disabled at startup.
        audioSources.Clear();
        particleSystems.Clear();
        animators.Clear();

        audioSources.AddRange(FindObjectsByType<AudioSource>(FindObjectsInactive.Include, FindObjectsSortMode.None));
        particleSystems.AddRange(FindObjectsByType<ParticleSystem>(FindObjectsInactive.Include, FindObjectsSortMode.None));
        animators.AddRange(FindObjectsByType<Animator>(FindObjectsInactive.Include, FindObjectsSortMode.None));
    }

    public void Pause()
    {
        SetPaused(true);
    }

    public void Resume()
    {
        SetPaused(false);
    }

    private void SetPaused(bool paused)
    {
        isPaused = paused;

        // Disable gameplay scripts (camera, player controls, etc.)
        if (disableWhilePaused != null)
        {
            foreach (var b in disableWhilePaused)
            {
                if (!b) continue;
                b.enabled = !paused;
            }
        }

        if (pausePanel) pausePanel.SetActive(paused);

        // Cursor is handled in LateUpdate to prevent the UI EventSystem
        // from overriding the lock state on the same frame we resume.

        // Freeze gameplay time
        Time.timeScale = paused ? 0f : 1f;

        if (paused)
        {
            // Audio
            audioWasPlaying.Clear();
            foreach (var a in audioSources)
            {
                if (!a) continue;
                audioWasPlaying[a] = a.isPlaying;
                a.Pause();
            }

            // Particles
            particleWasPlaying.Clear();
            foreach (var p in particleSystems)
            {
                if (!p) continue;
                particleWasPlaying[p] = p.isPlaying;
                p.Pause(true);
            }

            // Animators (important for unscaled-time UI/objects, or if timeScale doesn’t stop them)
            animatorSpeed.Clear();
            foreach (var an in animators)
            {
                if (!an) continue;
                animatorSpeed[an] = an.speed;
                an.speed = 0f;
            }
        }
        else
        {
            // Resume Audio to previous playing state
            foreach (var kv in audioWasPlaying)
            {
                if (!kv.Key) continue;
                if (kv.Value) kv.Key.UnPause();
            }

            // Resume Particles to previous playing state
            foreach (var kv in particleWasPlaying)
            {
                if (!kv.Key) continue;
                if (kv.Value) kv.Key.Play(true);
            }

            // Restore animator speeds
            foreach (var kv in animatorSpeed)
            {
                if (!kv.Key) continue;
                kv.Key.speed = kv.Value;
            }
        }
    }

    public void GoToMainMenu()
    {
        // Ensure time resumes before leaving the scene
        Time.timeScale = 1f;

        // If you have a global audio manager, you may want to stop music here too.
        SceneManager.LoadScene(mainMenuSceneName);
    }

    public void QuitGame()
    {
        Time.timeScale = 1f;

#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    void OnDisable()
    {
        // Safety: if this object is disabled while paused, don’t leave the game frozen
        if (isPaused) Time.timeScale = 1f;
    }
}
